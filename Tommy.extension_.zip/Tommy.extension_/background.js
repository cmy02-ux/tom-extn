function buildProxyConfig(proxy) {
  return {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: proxy.protocol === "socks4"
          ? "socks4"
          : proxy.protocol === "socks5"
          ? "socks5"
          : "http",
        host: proxy.ip,
        port: Number(proxy.port)
      },
      bypassList: ["localhost", "127.0.0.1", "::1"]
    }
  };
}

function clearProxy() {
  return new Promise((resolve) => {
    chrome.proxy.settings.clear({ scope: "regular" }, () => resolve());
  });
}

async function testConnection(timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch("https://www.google.com/generate_204", {
      signal: controller.signal,
      cache: "no-store",
      redirect: "follow"
    });

    clearTimeout(timer);
    return res.ok || res.status === 204;
  } catch (e) {
    clearTimeout(timer);
    return false;
  }
}

const PROXY_LIST_URL = "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/JP/data.json";

async function fetchJapanProxiesInBackground() {
  const res = await fetch(PROXY_LIST_URL, { cache: "no-store" });
  if (!res.ok) throw new Error("Gagal mengambil daftar proxy");

  const list = await res.json();

  return list.filter(
    p =>
      (p.protocol === "http" ||
        p.protocol === "socks4" ||
        p.protocol === "socks5") &&
      p.ip &&
      p.port
  );
}

async function enableProxyWithFallback(proxies) {
  for (const proxy of proxies.slice(0, 15)) {
    console.log(`[BG] Mencoba proxy: ${proxy.ip}:${proxy.port} (${proxy.protocol})`);

    await new Promise((resolve) => {
      chrome.proxy.settings.set(
        {
          value: buildProxyConfig(proxy),
          scope: "regular"
        },
        () => resolve()
      );
    });

    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError.message);
      continue;
    }

    await new Promise(r => setTimeout(r, 1000));

    const ok = await testConnection(5000);

    if (ok) {
      console.log(`[BG] Berhasil terhubung ke proxy: ${proxy.ip}:${proxy.port}`);
      return { success: true, proxy };
    }

    await clearProxy();
  }

  await clearProxy();
  return { success: false, error: "Semua proxy gagal terhubung" };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "TEST_DIRECT_FETCH") {
    (async () => {
      try {
        const res = await fetch("https://www.google.com/generate_204", {
          cache: "no-store"
        });
        sendResponse({ success: true, status: res.status });
      } catch (err) {
        sendResponse({
          success: false,
          error: err.name + ": " + err.message
        });
      }
    })();
    return true;
  }

  if (message.type === "ENABLE_PROXY") {
    (async () => {
      if (!(chrome.proxy && chrome.proxy.settings)) {
        sendResponse({
          success: false,
          reason: "chrome.proxy TIDAK TERSEDIA di browser ini"
        });
        return;
      }

      let result;

      if (message.proxy) {
        await new Promise((resolve) => {
          chrome.proxy.settings.set(
            {
              value: buildProxyConfig(message.proxy),
              scope: "regular"
            },
            () => resolve()
          );
        });

        if (chrome.runtime.lastError) {
          sendResponse({
            success: false,
            error: chrome.runtime.lastError.message
          });
          return;
        }

        await new Promise(r => setTimeout(r, 1000));

        const ok = await testConnection(5000);

        if (!ok) await clearProxy();

        result = {
          success: ok,
          proxy: message.proxy
        };
      } else {
        try {
          const proxies = await fetchJapanProxiesInBackground();
          result = await enableProxyWithFallback(proxies);
        } catch (err) {
          result = {
            success: false,
            error: err.message
          };
        }
      }

      sendResponse(result);
    })();

    return true;
  }

  if (message.type === "DISABLE_PROXY") {
    (async () => {
      await clearProxy();
      sendResponse({ success: true });
    })();
    return true;
  }

  if (message.type === "FETCH_JP_PROXIES") {
    (async () => {
      try {
        const proxies = await fetchJapanProxiesInBackground();
        sendResponse({
          success: true,
          proxies
        });
      } catch (err) {
        sendResponse({
          success: false,
          error: err.message
        });
      }
    })();

    return true;
  }
});