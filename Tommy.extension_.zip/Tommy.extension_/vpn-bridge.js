window.addEventListener('VPN_BRIDGE_REQUEST', async (e) => {
  const { requestId, action, payload } = e.detail;
  let result;

  switch (action) {
    case 'ENABLE_PROXY':
      result = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: 'ENABLE_PROXY', proxy: payload },
          (r) => resolve(r || { success: false, error: chrome.runtime.lastError?.message })
        );
      });
      break;

    case 'DISABLE_PROXY':
      result = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: 'DISABLE_PROXY' },
          (r) => resolve(r || { success: false, error: chrome.runtime.lastError?.message })
        );
      });
      break;

    case 'FETCH_PROXIES':
      result = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: 'FETCH_JP_PROXIES' },
          (r) => resolve(r || { success: false, error: chrome.runtime.lastError?.message })
        );
      });
      break;

    case 'TEST_DIRECT_FETCH_BRIDGE':
      result = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: 'TEST_DIRECT_FETCH' },
          (r) => resolve(r || { success: false, error: chrome.runtime.lastError?.message })
        );
      });
      break;

    case 'STORAGE_GET':
      result = await new Promise((resolve) => {
        chrome.storage.local.get(['active', 'proxy'], resolve);
      });
      break;

    case 'STORAGE_SET':
      result = await new Promise((resolve) => {
        chrome.storage.local.set(payload, () => resolve({ success: true }));
      });
      break;

    default:
      result = { success: false, error: 'Unknown action: ' + action };
  }

  window.dispatchEvent(new CustomEvent('VPN_BRIDGE_RESPONSE', {
    detail: { requestId, result }
  }));
});