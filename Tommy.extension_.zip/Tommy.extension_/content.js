
(function () {
  if (document.getElementById('fb-tools-floating-btn')) return;

  if (!document.getElementById('fb-tools-anim-style')) {
    const style = document.createElement('style');
    style.id = 'fb-tools-anim-style';
    style.innerHTML = `
      @keyframes spin-refresh { 100% { transform: rotate(360deg); } }
      .spin-active { animation: spin-refresh 0.6s linear infinite; }
    `;
    document.head.appendChild(style);
  }

function vpnBridgeCall(action, payload) {
  return new Promise((resolve) => {
    const requestId = 'vpn_' + Math.random().toString(36).slice(2);
    function handler(e) {
      if (e.detail.requestId === requestId) {
        window.removeEventListener('VPN_BRIDGE_RESPONSE', handler);
        resolve(e.detail.result);
      }
    }
    window.addEventListener('VPN_BRIDGE_RESPONSE', handler);
    window.dispatchEvent(new CustomEvent('VPN_BRIDGE_REQUEST', {
      detail: { requestId, action, payload }
    }));
  });
}

function setVpnStatus(state, text) {
  const statusEl = document.getElementById('vpn-status');
  const textEl = document.getElementById('vpn-status-text');
  if (statusEl) {
    statusEl.classList.remove('idle', 'loading', 'active', 'error');
    statusEl.classList.add(state);
  }
  if (textEl && text !== undefined) textEl.textContent = text;
}

async function testDirectFetch() {
  const result = await vpnBridgeCall('TEST_DIRECT_FETCH_BRIDGE');
  alert('HASIL TES FETCH TANPA PROXY:\n' + JSON.stringify(result, null, 2));
}

async function fetchJapanProxies() {
  const res = await vpnBridgeCall('FETCH_PROXIES');
  if (!res || !res.success) throw new Error(res && res.error ? res.error : "Gagal mengambil daftar proxy");
  return res.proxies || [];
}

async function enableVpn(btnVpn) {
  btnVpn.disabled = true;
  setVpnStatus('loading', 'Mengambil daftar proxy...');
  try {
    const proxies = await fetchJapanProxies();
    if (!proxies.length) throw new Error("Tidak ada proxy tersedia");

    const candidates = proxies.slice(0, 15);
    let applied = null;

    for (let i = 0; i < candidates.length; i++) {
      setVpnStatus('loading', `Mencoba proxy ${i + 1}/${candidates.length}...`);
      const r = await vpnBridgeCall('ENABLE_PROXY', candidates[i]);
      if (r && r.success) { applied = candidates[i]; break; }
    }

    if (!applied) throw new Error(`Semua ${candidates.length} proxy gagal, coba klik lagi`);

    await vpnBridgeCall('STORAGE_SET', { active: true, proxy: applied });
    setVpnStatus('active', 'TOM VPN ON (JEPANG)');
    return true;
  } catch (err) {
    setVpnStatus('error', 'Gagal: ' + err.message);
    setTimeout(() => setVpnStatus('idle', 'VPN OFF'), 3000);
    return false;
  } finally {
    btnVpn.disabled = false;
  }
}

async function disableVpn(btnVpn) {
  btnVpn.disabled = true;
  await vpnBridgeCall('DISABLE_PROXY');
  await vpnBridgeCall('STORAGE_SET', { active: false, proxy: null });
  setVpnStatus('idle', 'VPN OFF');
  btnVpn.disabled = false;
}

async function toggleVpn() {
  const btnVpn = document.getElementById('btn-vpn-jp');
  if (!btnVpn || btnVpn.disabled) return;
  const state = await vpnBridgeCall('STORAGE_GET');
  if (state && state.active) {
    disableVpn(btnVpn);
  } else {
    enableVpn(btnVpn);
  }
}

async function syncVpnStatus() {
  const state = await vpnBridgeCall('STORAGE_GET');
  setVpnStatus(state && state.active ? 'active' : 'idle', state && state.active ? 'VPN aktif (Jepang)' : 'VPN nonaktif');
}

  const floatBtn = document.createElement('button');
  floatBtn.id = 'fb-tools-floating-btn';
  floatBtn.innerHTML = '+';
  const baseStyle = `
  position: fixed;
  height: 50px;
  width: 50px;
  bottom: 240px;
  right: 10px;
  z-index: 999999;
  background-color: #4ddfff80;
  color:#aaaaaa;
  border: none;
  border-radius: 50px;
  font-family: "Optimistic Text", -apple-system, BlinkMacSystemFont, sans-serif;
  font-size: 22px; 
  font-weight: 700;
  box-shadow: 0 1px 4px rgba(0,0,0,0.3);
  cursor: pointer;
  transition: transform 0.1s ease, background-color 0.1s ease, color 0.1s ease;
  -webkit-tap-highlight-color: transparent;
  outline: none;
`;

  floatBtn.style.cssText = baseStyle;

  floatBtn.addEventListener('mouseenter', () => {
    floatBtn.style.backgroundColor = '#e0e0e0';
    floatBtn.style.color = '#a6a6a6';
  });

  floatBtn.addEventListener('mouseleave', () => {
    floatBtn.style.backgroundColor = '#71e6ff4a';
    floatBtn.style.color = '#b4b4b4';
    floatBtn.style.transform = 'scale(1)';
  });

  floatBtn.addEventListener('mousedown', () => {
    floatBtn.style.transform = 'scale(0.50)';
  });

  floatBtn.addEventListener('mouseup', () => {
    floatBtn.style.transform = 'scale(1)';
  });

  floatBtn.addEventListener('click', () => {
    floatBtn.style.backgroundColor = '#71e6ff4a';
    floatBtn.style.color = '#b4b4b4';
    
    if (floatBtn.innerHTML === '+') {
      floatBtn.innerHTML = '×';
    } else {
      floatBtn.innerHTML = '+';
    }
  });

  floatBtn.addEventListener('touchstart', () => {
    floatBtn.style.transform = 'scale(0.50)';
    floatBtn.style.backgroundColor = '#e0e0e0';
    floatBtn.style.color = '#007bff';
  }, { passive: true });

  floatBtn.addEventListener('touchend', () => {
    floatBtn.style.transform = 'scale(1)';
    setTimeout(() => {
      floatBtn.style.backgroundColor = '#71e6ff4a';
      floatBtn.style.color = '#b4b4b4';
    }, 100);
  }, { passive: true });

  floatBtn.onmouseover = () => floatBtn.style.transform = 'scale(1.05)';
  floatBtn.onmouseout = () => floatBtn.style.transform = 'scale(1)';

  document.body.appendChild(floatBtn);

  if (!document.getElementById('fb-tools-chat-btn')) {
    const chatBtn = document.createElement('button');
    chatBtn.id = 'fb-tools-chat-btn';
    chatBtn.innerHTML = `
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
  </svg>
`;

    const chatBtnStyle = `
  position: fixed;
  height: 48px;
  width: 48px;
  bottom: 170px;
  right: 10px;
  z-index: 999999;
  background-color: #4ddfff80;
  color: #aaaaaa;
  border: none;
  border-radius: 50px;
  font-family: "Optimistic Text", -apple-system, BlinkMacSystemFont, sans-serif;
  box-shadow: 0 1px 4px rgba(0,0,0,0.3);
  cursor: pointer;
  transition: transform 0.1s ease, background-color 0.1s ease, color 0.1s ease;
  -webkit-tap-highlight-color: transparent;
  outline: none;
  display: flex;
  align-items: center;
  justify-content: center;
`;
    chatBtn.style.cssText = chatBtnStyle;

    chatBtn.addEventListener('mouseenter', () => {
      chatBtn.style.backgroundColor = '#e0e0e0';
      chatBtn.style.color = '#a6a6a6';
    });

    chatBtn.addEventListener('mouseleave', () => {
      chatBtn.style.backgroundColor = '#71e6ff4a';
      chatBtn.style.color = '#b4b4b4';
      chatBtn.style.transform = 'scale(1)';
    });

    chatBtn.addEventListener('mousedown', () => {
      chatBtn.style.transform = 'scale(0.50)';
    });

    chatBtn.addEventListener('mouseup', () => {
      chatBtn.style.transform = 'scale(1)';
    });

    chatBtn.addEventListener('touchstart', () => {
      chatBtn.style.transform = 'scale(0.50)';
      chatBtn.style.backgroundColor = '#e0e0e0';
      chatBtn.style.color = '#007bff';
    }, { passive: true });

    chatBtn.addEventListener('touchend', () => {
      chatBtn.style.transform = 'scale(1)';
      setTimeout(() => {
        chatBtn.style.backgroundColor = '#71e6ff4a';
        chatBtn.style.color = '#b4b4b4';
      }, 100);
    }, { passive: true });

    chatBtn.onmouseover = () => chatBtn.style.transform = 'scale(1.05)';
    chatBtn.onmouseout = () => chatBtn.style.transform = 'scale(1)';

    chatBtn.addEventListener('click', () => {
      const existingChat = document.getElementById('fb-chat-box');
      if (existingChat) {
        existingChat.remove();
        return;
      }

      const chatBox = document.createElement('div');
      chatBox.id = 'fb-chat-box';
      chatBox.style.cssText = `
        position: fixed;
        bottom: 200px;
        right: 10px;
        width: 300px;
        height: 380px;
        background: transparent;
        z-index: 999999;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        font-family: "Optimistic Text", -apple-system, BlinkMacSystemFont, sans-serif;
        border: none;
      `;

      chatBox.innerHTML = `
        <div style="background: #333; color: #fff; border-radius: 0 70px 0 70px;padding: 4px 30px; font-weight: bold; font-size: 12px; display: flex; justify-content: space-between; align-items: center;width:78%; ">
          <span>Sistem Panduan</span>
          <button id="close-chat" style="background: transparent; border: none; color: white; font-size: 18px; cursor: pointer; line-height: 1;">×</button>
        </div>
        <div id="chat-content" style="flex: 1; overflow-y: auto; font-size: 12px; color: #333; display: flex; flex-direction: column; gap: 10px; padding:0 5px;">
          <div id="typing-msg" style="background: #fff; border: 1px solid #e0e0e0; box-shadow: 0 4px 12px rgba(0,0,0,0.15); padding:20px 10px; border-radius: 20px 0px 20px 20px; max-width: 100%; align-self: flex-end; line-height: 1.4; word-break: break-word; font-weight: 500;">
          </div>
        </div>
      `;

      document.body.appendChild(chatBox);

      document.getElementById('close-chat').onclick = () => chatBox.remove();

      const typingMsgEl = document.getElementById('typing-msg');
      const welcomeText = "Halo! Saya arahkan langsung dari sini.<br>Bagian nama karakter tidak valid atau di tolak tahap uji coba ubah jalur bagian (Pilih Interface, pilih FB_WEB ganti FB_LITE dll. atau coba ganti DOC ID jika kadaluarsa) Coba juga bantu dengan server vpn jpg, spain, dll.<br><br>Bagian Avatar guard klik Turn Shield ON, Pastikan Badge muncul di poto profil bagian bawah.<br><br>*Alat lainnya kunjungi <a href='https://tommy-sage.vercel.app/'>di selengkapnya sini</a><br>TERIMAKASIH<br>Tools by Tommy Adhelyno";
      let index = 0;
      let currentText = "";

      function startTyping() {
        if (index < welcomeText.length) {
          if (welcomeText.charAt(index) === '<') {
            let closingBracket = welcomeText.indexOf('>', index);
            if (closingBracket !== -1) {
              currentText += welcomeText.substring(index, closingBracket + 1);
              typingMsgEl.innerHTML = currentText;
              index = closingBracket + 1;
              setTimeout(startTyping, 40);
              return;
            }
          }
          currentText += welcomeText.charAt(index);
          typingMsgEl.innerHTML = currentText;
          index++;
          setTimeout(startTyping, 20);
        }
      }
      startTyping();
    });

    document.body.appendChild(chatBtn);
  }

  if (!document.getElementById('fb-tools-refresh-btn')) {
    const refreshBtn = document.createElement('button');
    refreshBtn.id = 'fb-tools-refresh-btn';
    
    refreshBtn.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"></path>
        <path d="M21 3v5h-5"></path>
      </svg>
    `;
    
    const refreshBtnStyle = `
      position: fixed;
      height: 48px;
      width: 48px;
      bottom: 100px; 
      right: 10px;
      z-index: 999999;
      background-color: #4ddfff80;
      color: #aaaaaa;
      border: none;
      border-radius: 50px;
      font-family: "Optimistic Text", -apple-system, BlinkMacSystemFont, sans-serif;
      box-shadow: 0 1px 4px rgba(0,0,0,0.3);
      cursor: pointer;
      transition: transform 0.1s ease, background-color 0.1s ease, color 0.1s ease;
      -webkit-tap-highlight-color: transparent;
      outline: none;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
      refreshBtn.style.cssText = refreshBtnStyle;
      
      refreshBtn.addEventListener('click', () => {
        const svgIcon = refreshBtn.querySelector('svg');
        if (svgIcon) svgIcon.classList.add('spin-active');
      
        let profileId = window.location.pathname.match(/\/profiles\/(\d+)/)?.[1];
      
      
        if (!profileId) {
          const userCookie = document.cookie.match(/c_user=(\d+)/);
          profileId = userCookie ? userCookie[1] : null;
        }
      
        setTimeout(() => {
          if (profileId) {
            window.location.href = `https://accountscenter.facebook.com/profiles/${profileId}/`;
          } else {
      
            window.location.href = 'https://accountscenter.facebook.com/profiles/';
          }
        }, 400);
      });

    refreshBtn.addEventListener('mouseenter', () => {
      refreshBtn.style.backgroundColor = '#e0e0e0';
      refreshBtn.style.color = '#a6a6a6';
    });

    refreshBtn.addEventListener('mouseleave', () => {
      refreshBtn.style.backgroundColor = '#71e6ff4a';
      refreshBtn.style.color = '#b4b4b4';
      refreshBtn.style.transform = 'scale(1)';
    });

    refreshBtn.addEventListener('mousedown', () => {
      refreshBtn.style.transform = 'scale(0.50)';
    });

    refreshBtn.addEventListener('mouseup', () => {
      refreshBtn.style.transform = 'scale(1)';
    });

    refreshBtn.addEventListener('touchstart', () => {
      refreshBtn.style.transform = 'scale(0.50)';
      refreshBtn.style.backgroundColor = '#e0e0e0';
      refreshBtn.style.color = '#007bff';
    }, { passive: true });

    refreshBtn.addEventListener('touchend', () => {
      refreshBtn.style.transform = 'scale(1)';
      setTimeout(() => {
        refreshBtn.style.backgroundColor = '#71e6ff4a';
        refreshBtn.style.color = '#b4b4b4';
      }, 100);
    }, { passive: true });

    refreshBtn.onmouseover = () => refreshBtn.style.transform = 'scale(1.05)';
    refreshBtn.onmouseout = () => refreshBtn.style.transform = 'scale(1)';

    document.body.appendChild(refreshBtn);
  }

  floatBtn.addEventListener('click', function () {

    const existingModal = document.getElementById('n');
    if (existingModal) {
      existingModal.remove();
      return;
    }
    
  (function () {
    function setDtsgStatus(status) {
        const overlay = document.getElementById('dtsg-overlay');
        if (!overlay) return;

  switch (status) {
    case 'LOADING':
        overlay.style.display = 'flex';
        overlay.style.color = '#e3b341'; 
        overlay.textContent = 'LOADING...';
        break;

    case 'COMPLETE':
        overlay.style.display = 'flex';
        overlay.style.color = '#2ea44f'; 
        overlay.textContent = 'COMPLETE';
        break;

    case 'ERROR':
        overlay.style.display = 'flex';
        overlay.style.color = '#f85149'; 
        overlay.textContent = 'ERROR!';
        break;

    case 'HIDE':
    default:
        overlay.style.display = 'none';
        break;
        }
       }

let fb_dtsg = '';
    let USER_ID = window.__user && window.__user !== '0' ? window.__user : '';
    let userName = '';
    let userPic = '';
    let fbUserId = '';
    let igUserId = ''; 

    
    const currentUrl = window.location.href;
    const isCurrentIG = currentUrl.includes('instagram.com') || (!currentUrl.includes('instagram.com') && !currentUrl.includes('facebook.com') && false);
    let initialInterface = (currentUrl.includes('instagram.com') || currentUrl.includes('accountscenter.instagram')) ? "IG_WEB" : "FB_WEB";

    try {
        const pageSource = document.documentElement.innerHTML;

        let dtsgMatch = pageSource.match(/"token":"([^"]+)"/);
        if (dtsgMatch && (dtsgMatch[1].startsWith('NA') || dtsgMatch[1].startsWith('AQ'))) fb_dtsg = dtsgMatch[1];
        
        if (!fb_dtsg) {
          dtsgMatch = pageSource.match(/"DTSGInitialData",\[\],{"token":"([^"]+)"/);
          if (dtsgMatch) fb_dtsg = dtsgMatch[1];
        }
        
        if (!fb_dtsg) {
          const dtsgEl = document.querySelector('input[name="fb_dtsg"]');
          if (dtsgEl) fb_dtsg = dtsgEl.value;
        }

        const inputDtsg = document.getElementById('d');
        if (inputDtsg && fb_dtsg) {
            inputDtsg.value = fb_dtsg;
        }

        if (document.getElementById('dtsg-overlay')) {
            if (fb_dtsg && fb_dtsg !== 'lokal_dtsg_dummy_12345') {
                setDtsgStatus('COMPLETE');
            } else {
                setDtsgStatus('ERROR');
            }
        }

        const extractUrlProfileId = (url) => {
            const match = url.match(/\/profiles\/(\d+)/) || url.match(/\/users\/(\d+)/) || url.match(/\/id\/(\d+)/) || url.match(/[?&]id=(\d+)/);
            return (match && match[1] !== '0') ? match[1] : '';
        };

        const extractIGId = (src, url) => {
            let idFromUrl = extractUrlProfileId(url);
            if (idFromUrl) return idFromUrl;

            const patterns = [
                /"id":"(\d+)","__typename":"XFamilyUser"/,
                /"fbid_v2":"(\d+)"/,
                /"account_type":"INSTAGRAM",[^}]*"id":"(\d+)"/,
                /"id":"(\d+)",[^}]*"account_type":"INSTAGRAM"/,
                /"instagram_user_id":"(\d+)"/,
                /"viewer_id":"(\d+)"/,
                /"viewerId":"(\d+)"/,
                /"igId":"(\d+)"/,
                /"profile_id":"(\d+)"/,
                /"pk":"(\d+)"/,
                /"EIMUser.*?id":"(\d+)"/,
                /"actorID":"(\d+)"/,
                /"userId":"(\d+)".*?"username"/
            ];

            for (let regex of patterns) {
                let match = src.match(regex);
                if (match && match[1] && match[1] !== '0') return match[1];
            }
            
            const igCookie = document.cookie.match(/ds_user_id=(\d+)/);
            if (igCookie && igCookie[1] !== '0') return igCookie[1];

            return '';
        };

        const extractFBId = (src, url) => {
            let idFromUrl = extractUrlProfileId(url);
            if (idFromUrl) return idFromUrl;

            const patterns = [
                /"ACTOR_ID":"(\d+)"/,
                /"USER_ID":"(\d+)"/,
                /"ACCOUNT_ID":"(\d+)"/,
                /"id":"(\d{10,})"/
            ];

            for (let regex of patterns) {
                let match = src.match(regex);
                if (match && match[1] && match[1] !== '0') return match[1];
            }

            const fbCookie = document.cookie.match(/c_user=(\d+)/);
            if (fbCookie && fbCookie[1] !== '0') return fbCookie[1];

            return '';
        };

        fbUserId = extractFBId(pageSource, currentUrl);
        igUserId = extractIGId(pageSource, currentUrl);

        if (isCurrentIG || currentUrl.includes('accountscenter.instagram.com') || currentUrl.includes('accountscenter.facebook.com')) {
            let igNameMatches = [
                pageSource.match(/"instagram_account":\{[^}]*"name":"([^"]+)"/),
                pageSource.match(/"accounts":\[\{[^}]*"name":"([^"]+)"/),
                pageSource.match(/"profile_name":"([^"]+)"/),
                pageSource.match(/"full_name":"([^"]+)",\s*"__typename":"IGUser"/),
                pageSource.match(/"full_name":"([^"]+)",\s*"username"/)
            ];
            
            for (let match of igNameMatches) {
                if (match && match[1] && !match[1].toLowerCase().includes('facebook')) {
                    userName = match[1];
                    break;
                }
            }
        } else {
            let nameMatch = pageSource.match(/"NAME":"([^"]+)"/) || pageSource.match(/"full_name":"([^"]+)"/);
            if (nameMatch && nameMatch[1]) userName = nameMatch[1];
        }

        if (!userName || userName === 'User Profile' || userName.toLowerCase().includes('pengaturan') || userName.toLowerCase().includes('account')) {
            const acElements = document.querySelectorAll('span, div');
            for (let el of acElements) {
                if (el.innerText && el.innerText.length > 2 && el.innerText.length < 30) {
                    let text = el.innerText.trim();
                    if (!text.toLowerCase().includes('facebook') && !text.toLowerCase().includes('account center') && !text.toLowerCase().includes('pusat akun')) {
                        userName = text;
                        break;
                    }
                }
            }
        }
        
        if (userName) {
            try {
                userName = userName.replace(/\\u[\dA-F]{4}/gi, match => String.fromCharCode(parseInt(match.replace(/\\u/g, ''), 16)));
            } catch(e) {}
        }

        const imgNodes = Array.from(document.querySelectorAll('img, image'));
        const profileImg = imgNodes.find(img => {
          const src = img.getAttribute('src') || img.getAttribute('xlink:href') || '';
          return src && (src.includes('scontent') || src.includes('cdninstagram')) && !src.includes('rsrc.php');
        });

        if (profileImg) {
          userPic = profileImg.getAttribute('src') || profileImg.getAttribute('xlink:href');
        } else {
          const picMatch = pageSource.match(/"profile_pic_url":"([^"]+)"/);
          if (picMatch) {
            userPic = picMatch[1].replace(/\\/g, '');
          }
        }
    } catch (e) {}

      if (!USER_ID || USER_ID === '0') {
        const igSpecificMatch = document.documentElement.innerHTML.match(/"instagram_user_id":"(\d+)"/) || 
                                document.documentElement.innerHTML.match(/"viewer_id":"(\d+)"/) ||
                                document.documentElement.innerHTML.match(/"pk":"(\d+)"/);
        if (igSpecificMatch && igSpecificMatch[1]) {
            USER_ID = igSpecificMatch[1];
        }
    }

    if (!USER_ID || USER_ID === '0') {
        const globalIdMatch = document.documentElement.innerHTML.match(/(?:"id"|"fbid"):"(\d{10,})"/);
        if (globalIdMatch && globalIdMatch[1] !== '0' && globalIdMatch[1] !== '9538143859625836') {
            USER_ID = globalIdMatch[1];
        }
    }

    if (!USER_ID || USER_ID === '0') {
        const allDigitsMatches = document.documentElement.innerHTML.match(/"id":"(\d{15,17})"/g);
        if (allDigitsMatches && allDigitsMatches.length > 0) {
            const cleanId = allDigitsMatches[0].match(/"id":"(\d+)"/)?.[1];
            if (cleanId) USER_ID = cleanId;
        }
    }

    if (!USER_ID || USER_ID === '0') USER_ID = window.location.href.match(/\/profiles\/(\d+)/)?.[1] || '';
    if (!fb_dtsg) fb_dtsg = '';
    if (!userName || userName.toLowerCase().includes('pengaturan') || userName.toLowerCase().includes('account')) userName = 'User Profile';
    if (!userPic) userPic = 'https://scontent.xx.fbcdn.net/v/t1.30497-1/143086968_2856368904622192_1959732218791162458_n.png?_nc_cat=1&ccb=1-7&_nc_sid=dbb9e7&_nc_ohc=placeholder';

  function createModal() {
    const overlay = document.createElement('div');
    overlay.id = 'n';
    overlay.style.cssText =
      'position:fixed;top:0;left:0;width:100%;height:100%;' +
      'background:rgba(0,0,0,0.6);z-index:9999;display:flex;' +
      'align-items:center;justify-content:center;' +
      'font-family: "Optimistic Text", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;';

    const box = document.createElement('div');
    box.style.cssText =
      'background:#fff;border-radius:30px;width:100%;max-width:350px;' +
      'max-height:100vh;overflow-y:auto;font-family: "Optimistic Text", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;';

    box.innerHTML = `
      <style>
        #n .h{text-align:center;padding:15px 15px 0px;position:relative; display: flex; align-items: center; -webkit-tap-highlight-color: transparent; outline: none; justify-content: space-between;}
        #n .x{position:absolute;top:12px;right:12px;border:0; font-size:24px;cursor:pointer;color:#050505;line-height:1}
        #n .p-sec{display:flex;align-items:center;padding:0px 14px;gap:5px; margin-top:10px;}
        #n .p-sec .p-pic-wrapper {position: relative; display: inline-block; border-radius: 50%; padding: 3px; transition: all 0.3s ease;}
        #n .p-sec img{width:100px;height:100px;border-radius:50%;object-fit:cover; border:3px solid #1877f2;box-shadow:0 1px 2px rgba(0,0,0,0.05); display: block;}
        #n .p-sec .p-pic-wrapper .shield-icon {display: none; position: absolute; bottom: 3px; right: 3px; z-index: 1;}
        #n .p-sec .p-pic-wrapper.active-guard .shield-icon {display: block !important;}
        #n .p-sec .p-info{display:flex;flex-direction:column}
        #n .p-sec .p-info strong{font-size:20px;color:#000000; font-weight:bold;}
        #n .d{margin:5px 20px;border: 1px solid #ccc; padding:10px;border-radius:15px;}
        #n .d span{display:block;font-size:20px;}
        #n .g{margin-top:4px;border: 1px solid #ccc;border-radius:8px;padding:8px;}
        #n .g label{display:block;font-size:12px;color:#333;margin-bottom:4px;}
        #n input{width:100%;font-size:15px; box-sizing:border-box; border:none; background:none;}
        #n input:focus{outline:0;border-color:#1877f2}
        #n input::placeholder {color: #333; opacity: 1;}
        #n .b {display: flex; margin-top: 0px; padding:10px 0px 20px 0px; gap:8px; justify-content: center; align-items: center; -webkit-tap-highlight-color: transparent;}
        #n .b > div {display: flex;}
        #n .b button {border: none; color: #333; background:#d7d7e7; padding: 0px 15px; height:35px; font-size: 14px; font-weight: 500; cursor: pointer; border-radius: 15px; transition: transform 0.2s ease; -webkit-tap-highlight-color: transparent; margin: 0px; user-select: none; -webkit-user-select: none;}
        @media (hover: hover) { #n .b button:hover { transform: scale(1.05); } }
        #n .b button:active {background:#c7c7c7; transform: scale(0.80);}
        #n #interface-select {border: 2px solid #888; color:#00adaa; padding:4px; border-radius: 8px; font-family:monospace; transform: scaleY(0.8); font-weight:900; background: #666; font-size: 13px; cursor: pointer; outline: none;}
      </style>

      <div class="h">
        <h2 style="color: #333; display: flex; align-items: center; gap: 0px; margin: 0;">
          ${window.location.hostname.includes('instagram.com') ? 
            ` <svg width="30" height="30" viewBox="0 0 220 240" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="bodyGloss" cx="35%" cy="25%" r="80%">
      <stop offset="0%" stop-color="#833AB4"/>
      <stop offset="45%" stop-color="#E1306C"/>
      <stop offset="100%" stop-color="#F77737"/>
    </radialGradient>
    <radialGradient id="headGloss" cx="38%" cy="22%" r="75%">
      <stop offset="0%" stop-color="#C13584"/>
      <stop offset="50%" stop-color="#E1306C"/>
      <stop offset="100%" stop-color="#833AB4"/>
    </radialGradient>
    <linearGradient id="beakGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFC24D"/>
      <stop offset="100%" stop-color="#F5920E"/>
    </linearGradient>
    <linearGradient id="footGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFB43D"/>
      <stop offset="100%" stop-color="#F08A0C"/>
    </linearGradient>
    <radialGradient id="bellyShade" cx="50%" cy="30%" r="70%">
      <stop offset="0%" stop-color="#FFFFFF"/>
      <stop offset="100%" stop-color="#E7E9EC"/>
    </radialGradient>
    <radialGradient id="eyePatch" cx="40%" cy="30%" r="75%">
      <stop offset="0%" stop-color="#FFFFFF"/>
      <stop offset="100%" stop-color="#DCE0E5"/>
    </radialGradient>
  </defs>

  <!-- bayangan -->
  <ellipse cx="128" cy="238" rx="58" ry="9" fill="#000000" opacity="0.15"/>

  <!-- sayap kiri -->
  <path d="M55 118 C30 145 26 190 48 218 C64 205 76 172 74 100 Z" fill="url(#bodyGloss)"/>
  <!-- sayap kanan -->
  <path d="M201 118 C226 145 230 190 208 218 C192 205 180 172 182 100 Z" fill="url(#bodyGloss)"/>

  <!-- kaki -->
  <path d="M92 220 Q100 232 112 230 Q118 232 122 224 Q126 234 134 230 Q118 236 100 234 Q92 232 92 220 Z" fill="url(#footGrad)"/>
  <path d="M134 220 Q142 232 154 230 Q160 232 164 224 Q168 234 176 230 Q160 236 142 234 Q134 232 134 220 Z" fill="url(#footGrad)"/>

  <!-- badan bulat -->
  <ellipse cx="128" cy="150" rx="76" ry="80" fill="url(#bodyGloss)"/>

  <!-- perut putih -->
  <ellipse cx="128" cy="168" rx="52" ry="60" fill="url(#bellyShade)"/>

  <!-- kepala -->
  <circle cx="128" cy="82" r="70" fill="url(#headGloss)"/>

  <!-- patch mata besar putih -->
  <ellipse cx="93" cy="88" rx="34" ry="38" fill="url(#eyePatch)"/>
  <ellipse cx="163" cy="88" rx="34" ry="38" fill="url(#eyePatch)"/>

  <!-- mata (dianimasikan kedip) -->
  <g class="eye eye-left" style="transform-origin: 90px 92px;">
    <circle cx="90" cy="92" r="16" fill="#1a1a1a"/>
    <circle cx="90" cy="92" r="13" fill="#2E5FA3"/>
    <circle cx="90" cy="92" r="7" fill="#111"/>
    <circle cx="85" cy="86" r="4" fill="#FFFFFF"/>
    <circle cx="95" cy="98" r="2" fill="#FFFFFF" opacity="0.8"/>
  </g>
  <g class="eye eye-right" style="transform-origin: 166px 92px;">
    <circle cx="166" cy="92" r="16" fill="#1a1a1a"/>
    <circle cx="166" cy="92" r="13" fill="#2E5FA3"/>
    <circle cx="166" cy="92" r="7" fill="#111"/>
    <circle cx="161" cy="86" r="4" fill="#FFFFFF"/>
    <circle cx="171" cy="98" r="2" fill="#FFFFFF" opacity="0.8"/>
  </g>

  <!-- kelopak mata (menutup saat kedip) -->
  <ellipse class="eyelid eyelid-left" cx="93" cy="88" rx="34" ry="0" fill="url(#eyePatch)"/>
  <ellipse class="eyelid eyelid-right" cx="163" cy="88" rx="34" ry="0" fill="url(#eyePatch)"/> ` : 
            `<svg width="30" height="30" viewBox="0 0 220 240" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="bodyGloss" cx="35%" cy="25%" r="80%">
      <stop offset="0%" stop-color="#4B92FF"/>
      <stop offset="45%" stop-color="#000000"/>
      <stop offset="100%" stop-color="#000000"/>
    </radialGradient>
    <radialGradient id="headGloss" cx="38%" cy="22%" r="75%">
      <stop offset="0%" stop-color="#2a303a"/>
      <stop offset="50%" stop-color="#0d1014"/>
      <stop offset="100%" stop-color="#0A4594"/>
    </radialGradient>
    <linearGradient id="beakGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFC24D"/>
      <stop offset="100%" stop-color="#F5920E"/>
    </linearGradient>
    <linearGradient id="footGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFB43D"/>
      <stop offset="100%" stop-color="#F08A0C"/>
    </linearGradient>
    <radialGradient id="bellyShade" cx="50%" cy="30%" r="70%">
      <stop offset="0%" stop-color="#FFFFFF"/>
      <stop offset="100%" stop-color="#E7E9EC"/>
    </radialGradient>
    <radialGradient id="eyePatch" cx="40%" cy="30%" r="75%">
      <stop offset="0%" stop-color="#FFFFFF"/>
      <stop offset="100%" stop-color="#DCE0E5"/>
    </radialGradient>
  </defs>
  
  <ellipse cx="128" cy="238" rx="58" ry="9" fill="#000000" opacity="0.15"/>

  <path d="M55 118 C30 145 26 190 48 218 C64 205 76 172 74 100 Z" fill="url(#bodyGloss)"/>
  <!-- sayap kanan -->
  <path d="M201 118 C226 145 230 190 208 218 C192 205 180 172 182 100 Z" fill="url(#bodyGloss)"/>

  <path d="M92 220 Q100 232 112 230 Q118 232 122 224 Q126 234 134 230 Q118 236 100 234 Q92 232 92 220 Z" fill="url(#footGrad)"/>
  <path d="M134 220 Q142 232 154 230 Q160 232 164 224 Q168 234 176 230 Q160 236 142 234 Q134 232 134 220 Z" fill="url(#footGrad)"/>

  <ellipse cx="128" cy="150" rx="76" ry="80" fill="url(#bodyGloss)"/>

  <ellipse cx="128" cy="168" rx="52" ry="60" fill="url(#bellyShade)"/>

  <circle cx="128" cy="82" r="70" fill="url(#headGloss)"/>

  <ellipse cx="93" cy="88" rx="34" ry="38" fill="url(#eyePatch)"/>
  <ellipse cx="163" cy="88" rx="34" ry="38" fill="url(#eyePatch)"/>

  <g class="eye eye-left" style="transform-origin: 90px 92px;">
    <circle cx="90" cy="92" r="16" fill="#1a1a1a"/>
    <circle cx="90" cy="92" r="13" fill="#2E5FA3"/>
    <circle cx="90" cy="92" r="7" fill="#111"/>
    <circle cx="85" cy="86" r="4" fill="#FFFFFF"/>
    <circle cx="95" cy="98" r="2" fill="#FFFFFF" opacity="0.8"/>
  </g>
  <g class="eye eye-right" style="transform-origin: 166px 92px;">
    <circle cx="166" cy="92" r="16" fill="#1a1a1a"/>
    <circle cx="166" cy="92" r="13" fill="#2E5FA3"/>
    <circle cx="166" cy="92" r="7" fill="#111"/>
    <circle cx="161" cy="86" r="4" fill="#FFFFFF"/>
    <circle cx="171" cy="98" r="2" fill="#FFFFFF" opacity="0.8"/>
  </g>

  <ellipse class="eyelid eyelid-left" cx="93" cy="88" rx="34" ry="0" fill="url(#eyePatch)"/>
  <ellipse class="eyelid eyelid-right" cx="163" cy="88" rx="34" ry="0" fill="url(#eyePatch)"/>`
          }

  <style>
    .eye { animation: blinkEye 2s infinite; }
    .eyelid { animation: blinkLid 4.5s infinite; }
    .eye-right, .eyelid-right { animation-delay: 0s; }

    @keyframes blinkEye {
      0%, 92%, 100% { transform: scaleY(1); }
      95% { transform: scaleY(0.05); }
    }
    @keyframes blinkLid {
      0%, 92%, 100% { ry: 0; }
      95% { ry: 39; }
    }
    
      .vpn-status {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-family: Arial, sans-serif;
        font-size: 12px;
        font-weight: bold;
        padding: 4px 8px;
        border-radius: 20px;
        transition: background 0.25s ease, color 0.25s ease;
      }
      #vpn-status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
      }
      
      /* idle */
      .vpn-status.idle { background:#eee; color:#555; }
      .vpn-status.idle #vpn-status-dot { background:#999; }
      
      /* loading */
      .vpn-status.loading { background:#e8f0fe; color:#1877F2; }
      .vpn-status.loading #vpn-status-dot {
        background:#1877F2;
        animation: vpn-blink 0.9s ease-in-out infinite;
      }
      @keyframes vpn-blink {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.2; }
      }
      
      /* active */
      .vpn-status.active { background:#e6f9ee; color:#1c8a4b; }
      .vpn-status.active #vpn-status-dot {
        background:#2ecc71;
        animation: vpn-pulse 1.6s ease-in-out infinite;
      }
      @keyframes vpn-pulse {
        0%   { box-shadow: 0 0 0 0 rgba(46,204,113,0.6); }
        70%  { box-shadow: 0 0 0 6px rgba(46,204,113,0); }
        100% { box-shadow: 0 0 0 0 rgba(46,204,113,0); }
      }
      
      /* error */
      .vpn-status.error { background:#fdeaea; color:#c0392b; }
      .vpn-status.error #vpn-status-dot { background:#e02424; }
      
      
        </style>
      
        <!-- paruh -->
        <path d="M112 108 Q128 100 144 108 Q140 128 128 138 Q116 128 112 108 Z" fill="url(#beakGrad)"/>
        <path d="M113 118 Q128 124 143 118" stroke="#D9780A" stroke-width="2" fill="none" opacity="0.6"/>
      
        <!-- highlight kepala -->
        <ellipse cx="105" cy="45" rx="22" ry="14" fill="#ffffff" opacity="0.15"/>
        <!-- highlight badan -->
        <ellipse cx="100" cy="115" rx="20" ry="12" fill="#ffffff" opacity="0.12"/>
      </svg>
      <a style="font-size:25px;color:#444;transform: scaleX(0.8);"><b>Edit name | </b><a style="color:#1877F2; font-size: 15px; text-align: left; display: block;transform: scaleX(0.8);
      transform-origin: left;">
        Avatar guard
        <footer style="color: #888; font-size: 9px; transform: scaleX(0.9);
      transform-origin: left; font-weight: 500; ">
    ©Tommy. All rights reserved.
  </footer>
              </a>
        </h2>
        
      <button id="x" style="background: #ececec; border: 1px solid #ccc; border-radius: 50px; width: 25px; height: 25px; cursor: pointer; font-size: 14px; display: flex; align-items: center; justify-content: center; padding: 0; position: relative;">×</button>
      
      <div id="vpn-status" class="vpn-status idle" style="position: absolute; top: 100%; left: 48%; transform:  margin-top: 4px; white-space: nowrap; max-width: 125px;">
        <span id="vpn-status-dot"></span>
        <span id="vpn-status-text" style="transform: scaleY(0.8); transform-origin: left; display: inline-block; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: bottom;">VPN OFF</span>
      </div>
      </div>

      <div class="p-sec">
        <div class="p-pic-wrapper" id="p-pic-wrapper">
          <img id="p-pic" src="${userPic}" alt="Profile">
          <img class="shield-icon" width="24" height="24" src="https://static.xx.fbcdn.net/rsrc.php/yH/r/jXG4CPoC8L_.webp?_nc_eh=2%2C79e96e74d7c9caa5b811c8ba4d3f541c%2CAWguBO5inV_wDmnaikU0qdYVRSWk445Ff-c3mYvBl--UoNW7DsMLNIyz7K23pT3Nzi8" style="filter: drop-shadow(2px 2px 3px rgba(0, 0, 0, 0.1));" />
        </div>
        <div class="p-info">
          <strong id="p-name">${userName}</strong>
        <span style="display: inline-block; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: bottom;">
          <strong id="p-name" style="font-size: 14px; font-weight: bold; background: linear-gradient(to right, #e60000, #c800fc, #1bb300, #067cff, #f800d7); -webkit-background-clip: text; -webkit-text-fill-color: transparent; display: inline-block;">${userName}</strong>
        </span>
        </div>
      </div>

      <div class="u" style="display: flex; gap: 15px; margin: 8px 20px;">
        <div style="display: flex; flex-direction: column; flex: 1; min-width: 0;margin-top: 3px;">
          <label style="font-weight:800; color:#333; margin-bottom: 3px; font-size: 10px;">USER ID</label> 
    <input id="u" value="${USER_ID}" placeholder="Ketuk scan ID..." style="color:#999; padding:0 5px; border-radius: 10px; font-family:monospace; transform: scaleY(0.8); font-weight:900; border: 1px solid #ccc; height:25px; width: 100%; min-width:130px;font-size: 12px; letter-spacing: 2px; box-sizing: border-box;transform: scaleX(0.8);margin-top:3px;
    transform-origin: left;">
            </div>
    <style>
      .btn-fx {
        -webkit-tap-highlight-color: transparent;
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        user-select: none;
        outline: none;
        transition: filter 0.12s ease, transform 0.12s ease;
      }
      .btn-fx:hover {
        filter: brightness(1.1);
      }
      #btn-scan:active {
        transform: scaleX(0.8) scale(0.90) !important;
      }
      #btn-shield:active {
        transform: scaleX(0.8) scale(0.90) !important;
      }
    </style>
    
    <div style="display: flex; flex-direction: column; flex: 0.5; min-width: 0; justify-content: flex-end;">
      <button id="btn-scan" class="btn-fx" type="button" style="width: 100%; min-width:80px; height: 25px; background:#1877f2; transform: scaleY(0.8); color: #fff; border: none; border-radius: 10px; font-weight: bold; cursor: pointer; margin-bottom:1px; font-size: 12px;transform: scaleX(0.8);
    transform-origin: left;">Scan id</button>
    </div>
    <div style="display: flex; flex-direction: column; flex: 1; min-width: 0;">
      <label style="font-weight:800; color:#333; margin-bottom: 6px; font-size: 12px;">Avatar</label>
      <button id="btn-shield" class="btn-fx" type="button" style="width: 125%; height: 25px; background:#1877f2; transform: scaleX(0.8);
    transform-origin: left; color: #fff; border: none; border-radius: 10px; font-weight: bold; cursor: pointer; padding: 0;  font-size:12px;">Turn Shield ON</button>
    </div>
    </div>
      <div class="d">
        <div style=" gap: 20px; align-items: flex-end; margin-bottom: 8px;">

<div style="display: flex; gap: 10px; width: 100%; align-items: flex-end;">

  <!-- Bagian DTSG -->
  <div style="flex: 1; display: flex; flex-direction: column;">
    <label style="display: flex; font-weight:800; color:#333; margin-bottom: 0px; font-size: 12px;">Playload</label> 
    <div style="position: relative; width: 100%; height: 30px;">
      <input id="d" disabled value="${fb_dtsg}" style="color:#666; padding:8px; border-radius: 10px; font-family:monospace; transform: scaleY(0.8); font-weight:900; border: 1px solid #ccc; height:100%; width: 100%; box-sizing: border-box;">
      <div id="dtsg-overlay" style="
        display: flex;
        position: absolute;
        top: 0; left: 0; 
        width: 100%; height: 100%;
        z-index: 10;
        background: #fff;
        border-radius: 10px;
        border:1px solid #ccc;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 11px;
        transform: scaleY(0.8);
        letter-spacing: 5px;
        box-sizing: border-box;
        color: ${fb_dtsg && fb_dtsg !== 'lokal_dtsg_dummy_12345' ? '#009d2c' : '#f03737'};
      ">
        ${fb_dtsg && fb_dtsg !== 'lokal_dtsg_dummy_12345' ? 'COMPLETE' : 'ERROR!'}
      </div>
    </div>
  </div>

  <!-- Bagian GANTI DOC ID -->
  <div style="flex: 1; display: flex; flex-direction: column;">
    <label style="font-weight:800; color:#333; margin-bottom: 3px; font-size: 12px;">Ganti doc</label> 
<div style="display: flex; flex-direction: column; flex: 1; min-width: 0;transform: scaleX(0.8);
transform-origin: left;margin-bottom: 3px; ">
  <input 
    type="text" 
    id="name-doc-id" 
    value="9538143859625836" 
    style="height: 25px; padding: 0 8px; font-size: 12px; background: #d7d7e7; font-family: monospace; font-weight: 800; text-align: center; color: #999; border: 1px solid #ccc; border-radius: 10px; outline: none; margin: 0; box-sizing: border-box; width: 125%; letter-spacing: 5px;"
  >
</div>
    </div>
  </div>
</div>
<div style="display: flex; gap: 11px; ">
  <div style="display: flex; flex-direction: column; flex: 1; min-width: 0;">
    <label for="interface-select" style="font-weight:800; color:#333; margin-bottom: 2px; font-size: 12px;">Pilih Interface</label>
    <select id="interface-select" style="width: 125%;; height: 25px; border: 1px solid #ccc; color:#333; padding: 4px; border-radius: 10px; font-family:monospace; transform: scaleX(0.8); transform-origin: left; font-weight:900; font-size: 12px; cursor: pointer; outline: none; background:#d7d7e7;">
      
      <optgroup label="Facebook">
        <option value="FB_WEB" ${initialInterface === 'FB_WEB' ? 'selected' : ''}>Web version</option>
        <option value="FB_MTOUCH">FB_MTOUCH</option>
        <option value="FB_LITE">FB_LITE</option>
      </optgroup>
      <optgroup label="Instagram">
        <option value="IG_WEB" ${initialInterface === 'IG_WEB' ? 'selected' : ''}>IG_WEB</option>
        <option value="IG_LITE">IG_LITE</option>
      </optgroup>
      <optgroup label="Messenger">
        <option value="MESSENGER_WEB">MESSENGER_WEB</option>
        <option value="MESSENGER_LITE">MESSENGER_LITE</option>
      </optgroup>
      <optgroup label="Threads">
        <option value="THREADS_WEB">THREADS_WEB</option>
        <option value="THREADS_LITE">THREADS_LITE</option>
    </select>
  </div>

<div style="display: flex; flex-direction: column; flex: 1; min-width: 0;">

<div style="display: flex; flex-direction: column; flex: 1; min-width: 0;">

<label style="font-weight:800; color:#333; margin-top: 0px; font-size: 12px; display: block;">friendlyName</label> 
<select 
  id="friendlyNameInput" 
  style="font-size: 12px; margin-top: 2px; color:#333; padding:0 8px; border-radius: 10px; font-family:monospace; transform: scaleX(0.8); transform-origin: left; font-weight:900; border: 1px solid #ccc; height:25px; width: 125%; box-sizing: border-box; background-color: #d7d7e7;"
>
  <option value="useFXIMNameValidatorQuery">Validation</option>
  <option value="useBarcelonaEditProfileMutation">Edit Profile</option>
  <option value="useFXINUpdateNameMutation">Update</option>
</select>

</div>
</div>
</div>
    <span style="margin: 5px 0; font-size: 13px; font-weight: 900; width: 100%; color: #333;">Edit name</span>
        <div class="g">
          <label>Full Name (Satu Kolom Full Name)</label>
          <input type="text" id="fn" placeholder="Masukkan nama lengkap di sini" value="${userName !== 'User Profile' ? userName : ''}" />
        </div>
        <div class="g">
          <label>First(opsional)</label>
          <input type="text" id="first-name" placeholder="Name" />
        </div>
        <div class="g">
          <label>Last(opsional)</label>
          <input type="text" id="last-name" placeholder="Name" />
        </div>
        </div>
<div class="b">

  <div style="display:inline-flex; margin:0; padding:0; line-height:0;">
    <a href="https://tommy-app-rouge.vercel.app" target="_blank" style="text-decoration: none; display:inline-flex; line-height:0;">
      <button type="button" title="Tools"
        style="cursor: pointer; border:none; background:#1877f2; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0; padding:0;">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="#fff"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
      </button>
    </a>
  </div>
  <a href="https://x10-sigma.vercel.app/" target="_blank" style="text-decoration: none; display:inline-flex; line-height:0;">
  <button type="button" title="Tools"
    style="cursor: pointer; border:none; background:#1877f2; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0; padding:0;">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="#fff">
      <path d="M20 5H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zM8 8h2v2H8V8zm0 3h2v2H8v-2zM5 8h2v2H5V8zm0 3h2v2H5v-2zm3 6H5v-2h3v2zm3-6h2v2h-2v-2zm0-3h2v2h-2V8zm0 9h-2v-2h2v2zm3-3h-2v-2h2v2zm0-3h-2V8h2v2zm3 6h-6v-2h6v2zm0-6h-2V8h2v2zm3 3h-2v-2h2v2zm0-3h-2V8h2v2z"/>
    </svg>
  </button>
</a>

<button class="vpn" id="btn-vpn-jp" type="button" title="VPN Jepang"
  style="cursor:pointer; border:none; background:#01a80e; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0; padding:0; -webkit-tap-highlight-color: transparent; outline:none; transition: filter 0.12s ease, transform 0.12s ease; position: relative;">
  <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path fill="#fff" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm6.93 6h-2.95c-.32-1.25-.78-2.45-1.38-3.56A8.03 8.03 0 0 1 18.93 8zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14A7.94 7.94 0 0 1 4 12c0-.69.1-1.36.26-2h3.38c-.08.66-.14 1.32-.14 2s.06 1.34.14 2H4.26zm.81 2h2.95c.32 1.25.78 2.45 1.38 3.56A7.99 7.99 0 0 1 5.07 16zm2.95-8H5.07a7.99 7.99 0 0 1 4.33-3.56C8.8 5.55 8.34 6.75 8.02 8zM12 19.96c-.83-1.2-1.48-2.53-1.91-3.96h3.82c-.43 1.43-1.08 2.76-1.91 3.96zM14.34 14H9.66c-.09-.66-.16-1.32-.16-2s.07-1.35.16-2h4.68c.09.65.16 1.32.16 2s-.07 1.34-.16 2zm.25 5.56c.6-1.11 1.06-2.31 1.38-3.56h2.95a8.03 8.03 0 0 1-4.33 3.56zM16.36 14c.08-.66.14-1.32.14-2s-.06-1.34-.14-2h3.38c.16.64.26 1.31.26 2s-.1 1.36-.26 2h-3.38z"/>
  </svg>
</button>
<div>
<a id="accountCenterLink" href="#" target="_blank" style="text-decoration: none;">
  <button type="button" style="cursor: pointer; border:none; background:#1877f2; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0; padding:0; color:#fff;" title="Sinkronisasi Account Center">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
  <path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46A7.93 7.93 0 0020 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74A7.93 7.93 0 004 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"/>
</svg>
  </button>
</a>
</div>
        <div>
          <button id="btn-sync-name" type="button" style="cursor: pointer; border:none; display: flex; align-items: center; justify-content: center; padding: 0px 10px;" title="Sinkronkan">V.02
          </button>
        </div>

        <button class="bs" id="s">Lanjutkan</button>
      </div>
    `;

overlay.appendChild(box);
document.body.appendChild(overlay);

document.getElementById('x').onclick = () => overlay.remove();

document.getElementById('s').onclick = submitName;
document.getElementById('btn-shield').onclick = () => {
    document.getElementById('p-pic-wrapper').classList.toggle('active-guard');
};

document.getElementById('btn-sync-name').onclick = async () => {
    const targetUid = document.getElementById('u')?.value;
    if (!targetUid) {
        alert('⚠️ User ID belum terdeteksi!');
        return;
    }

const promptCustomName = () => {
 return new Promise((resolve) => {
let overlay = document.createElement('div');
overlay.id = 'custom-prompt-overlay';
overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:999999;display:flex;align-items:center;justify-content:center;font-family:sans-serif;';
            
  overlay.innerHTML = `
    <div style="background:#fff;padding:20px;border-radius:30px;width:80%;max-width:320px;box-shadow:0 4px 15px rgba(0,0,0,0.3);">
        <div style="font-size:19px;font-weight:bold;margin-bottom:15px;color:#333;display:flex;align-items:center;gap:8px;">
            <svg width="27" height="27" viewBox="0 0 220 240" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <radialGradient id="bodyGloss" cx="35%" cy="25%" r="80%">
                        <stop offset="0%" stop-color="#4a4a52"/>
                        <stop offset="45%" stop-color="#26262c"/>
                        <stop offset="100%" stop-color="#0d0d10"/>
                    </radialGradient>
                    <radialGradient id="headGloss" cx="38%" cy="22%" r="75%">
                        <stop offset="0%" stop-color="#5c5c66"/>
                        <stop offset="50%" stop-color="#232329"/>
                        <stop offset="100%" stop-color="#0a0a0c"/>
                    </radialGradient>
                    <linearGradient id="beakGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stop-color="#FFC24D"/>
                        <stop offset="100%" stop-color="#F5920E"/>
                    </linearGradient>
                    <linearGradient id="footGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stop-color="#FFB43D"/>
                        <stop offset="100%" stop-color="#F08A0C"/>
                    </linearGradient>
                    <radialGradient id="bellyShade" cx="50%" cy="30%" r="70%">
                        <stop offset="0%" stop-color="#FFFFFF"/>
                        <stop offset="100%" stop-color="#E7E9EC"/>
                    </radialGradient>
                    <radialGradient id="eyePatch" cx="40%" cy="30%" r="75%">
                        <stop offset="0%" stop-color="#FFFFFF"/>
                        <stop offset="100%" stop-color="#DCE0E5"/>
                    </radialGradient>
                </defs>

                <!-- bayangan -->
                <ellipse cx="128" cy="238" rx="58" ry="9" fill="#000000" opacity="0.15"/>

                <!-- sayap kiri -->
                <path d="M55 118 C30 145 26 190 48 218 C64 205 76 172 74 100 Z" fill="url(#bodyGloss)"/>
                <!-- sayap kanan -->
                <path d="M201 118 C226 145 230 190 208 218 C192 205 180 172 182 100 Z" fill="url(#bodyGloss)"/>

                <!-- kaki -->
                <path d="M92 220 Q100 232 112 230 Q118 232 122 224 Q126 234 134 230 Q118 236 100 234 Q92 232 92 220 Z" fill="url(#footGrad)"/>
                <path d="M134 220 Q142 232 154 230 Q160 232 164 224 Q168 234 176 230 Q160 236 142 234 Q134 232 134 220 Z" fill="url(#footGrad)"/>

                <!-- badan bulat -->
                <ellipse cx="128" cy="150" rx="76" ry="80" fill="url(#bodyGloss)"/>

                <!-- perut putih -->
                <ellipse cx="128" cy="168" rx="52" ry="60" fill="url(#bellyShade)"/>

                <!-- kepala -->
                <circle cx="128" cy="82" r="70" fill="url(#headGloss)"/>

                <!-- patch mata besar putih -->
                <ellipse cx="93" cy="88" rx="34" ry="38" fill="url(#eyePatch)"/>
                <ellipse cx="163" cy="88" rx="34" ry="38" fill="url(#eyePatch)"/>

                <!-- mata (dianimasikan kedip) -->
                <g class="eye eye-left" style="transform-origin: 90px 92px;">
                    <circle cx="90" cy="92" r="16" fill="#1a1a1a"/>
                    <circle cx="90" cy="92" r="13" fill="#2E5FA3"/>
                    <circle cx="90" cy="92" r="7" fill="#111"/>
                    <circle cx="85" cy="86" r="4" fill="#FFFFFF"/>
                    <circle cx="95" cy="98" r="2" fill="#FFFFFF" opacity="0.8"/>
                </g>
                <g class="eye eye-right" style="transform-origin: 166px 92px;">
                    <circle cx="166" cy="92" r="16" fill="#1a1a1a"/>
                    <circle cx="166" cy="92" r="13" fill="#2E5FA3"/>
                    <circle cx="166" cy="92" r="7" fill="#111"/>
                    <circle cx="161" cy="86" r="4" fill="#FFFFFF"/>
                    <circle cx="171" cy="98" r="2" fill="#FFFFFF" opacity="0.8"/>
                </g>

                <!-- kelopak mata (menutup saat kedip) -->
                <ellipse class="eyelid eyelid-left" cx="93" cy="88" rx="34" ry="0" fill="url(#eyePatch)"/>
                <ellipse class="eyelid eyelid-right" cx="163" cy="88" rx="34" ry="0" fill="url(#eyePatch)"/>

                <style>
                    .eye { animation: blinkEye 2s infinite; }
                    .eyelid { animation: blinkLid 4.5s infinite; }
                    .eye-right, .eyelid-right { animation-delay: 0s; }

                    @keyframes blinkEye {
                        0%, 92%, 100% { transform: scaleY(1); }
                        95% { transform: scaleY(0.05); }
                    }
                    @keyframes blinkLid {
                        0%, 92%, 100% { ry: 0; }
                        95% { ry: 39; }
                    }
                </style>

                <!-- paruh -->
                <path d="M112 108 Q128 100 144 108 Q140 128 128 138 Q116 128 112 108 Z" fill="url(#beakGrad)"/>
                <path d="M113 118 Q128 124 143 118" stroke="#D9780A" stroke-width="2" fill="none" opacity="0.6"/>

                <!-- highlight kepala -->
                <ellipse cx="105" cy="45" rx="22" ry="14" fill="#ffffff" opacity="0.15"/>
                <!-- highlight badan -->
                <ellipse cx="100" cy="115" rx="20" ry="12" fill="#ffffff" opacity="0.12"/>
            </svg>
            <span style="vertical-align:middle;">Version 0.2</span>
        </div>

        <div style="position:relative;margin-bottom:1px;">
            <span style="position:absolute;top:-8px;left:10px;background:#fff;padding:0 4px;font-size:12px;color:#555;font-weight:bold;">Full Name</span>
            <input type="text" id="custom-name-input" value="${document.getElementById('fn')?.value || ""}" style="width:100%;padding:10px 12px;border:1px solid #3597ff; height:50px;margin-bottom:10px;border-radius:20px;box-sizing:border-box;font-size:14px;outline:none;" />
        </div>

        <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button id="custom-btn-cancel" style="background:#d7d7e7;color:#333;border:none;padding:8px 16px;border-radius:20px;font-weight:bold;cursor:pointer;">Batal</button>
            <button id="custom-btn-ok" style="background:#007bff;color:#fff;border:none;padding:8px 16px;border-radius:20px;font-weight:bold;cursor:pointer;">Lanjutkan</button>
        </div>
    </div>
`;
      document.body.appendChild(overlay);

            const inputEl = document.getElementById('custom-name-input');
            inputEl.focus();
            inputEl.select();

            document.getElementById('custom-btn-cancel').onclick = () => {
                overlay.remove();
                resolve(null);
            };

            document.getElementById('custom-btn-ok').onclick = () => {
                const val = inputEl.value;
                overlay.remove();
                resolve(val);
            };
        });
    };

    const enteredName = await promptCustomName();
    if (!enteredName) return;

    const tokenDtsgVal = fb_dtsg || document.querySelector('input[name="fb_dtsg"]')?.value;
    if (!tokenDtsgVal) {
        alert('⚠️ Token fb_dtsg tidak ditemukan!');
        return;
    }

    const isIG = window.location.hostname.includes('instagram.com');
    const gqlEndpoint = isIG ? 'https://www.instagram.com/api/graphql/' : 'https://www.facebook.com/api/graphql/';
    
    let igDid = '';
    if (isIG) {
        const matchDid = document.cookie.match(/ig_did=([^;]+)/);
        if (matchDid) igDid = matchDid[1];
    }

    const selectedInterface = document.getElementById('interface-select')?.value || initialInterface || (isIG ? 'IG_WEB' : 'FB_WEB');
    
    const variables = {
        client_mutation_id: 'crypto_' + Math.random().toString(36).substring(2),
        family_device_id: isIG ? (igDid || 'device_id_fetch_ig') : (selectedInterface.includes('IG') ? 'device_id_fetch_ig_did' : 'device_id_fetch_datr'),
        identity_ids: [targetUid],
        full_name: enteredName,
        first_name: null,
        middle_name: null,
        last_name: null,
        interface: selectedInterface
    };

    const formData = new URLSearchParams();
    formData.append('fb_dtsg', tokenDtsgVal);
    formData.append('doc_id', '9538143859625836');
    formData.append('variables', JSON.stringify(variables));
    formData.append('server_timestamps', 'true');

    const showStatusOverlay = (message) => {
        let overlay = document.getElementById('custom-status-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'custom-status-overlay';
            overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;font-family:sans-serif;';
            document.body.appendChild(overlay);
        }
        overlay.innerHTML = `
            <div style="border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin-bottom: 15px;"></div>
            <div style="font-size: 10px; font-weight: 700; text-align: center; padding: 0 20px;color:#ccc;">${message}</div>
            <style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>
        `;
    };

    showStatusOverlay(`TOMMY WEB PROCESSING`);

    try {
        const response = await fetch(gqlEndpoint, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: formData.toString()
        });
        
        const result = await response.json();
        console.log('Hasil Eksekusi Sinkron:', result);

        const succOverlay = document.getElementById('custom-status-overlay');
        if (succOverlay) {
            succOverlay.innerHTML = `<div style="font-size: 16px; font-weight: bold;">${enteredName}</div>`;
        }
        setTimeout(() => {
            if (succOverlay) succOverlay.remove();
            location.reload();
        }, 1000);

    } catch (err) {
        console.error('Gagal mengeksekusi script :', err);
        const errOverlay = document.getElementById('custom-status-overlay');
        if (errOverlay) errOverlay.remove();
        alert('ERROR!');
    }
};


    const runScanId = (isAutomatic = false) => {
        const html = document.documentElement.innerHTML;
        let foundId = '';

        const igPatterns = [
            /"userId":"(\d+)"/,
            /"pk":"(\d+)"/,
            /"id":"(\d+)","__typename":"XFamilyUser"/,
            /"instagram_user_id":"(\d+)"/,
            /instagram_id[ '"]*:[ '"]*["']?(\d+)/i
        ];

        for (let pat of igPatterns) {
            let m = html.match(pat);
            if (m && m[1] && m[1] !== '0') {
                foundId = m[1];
                break;
            }
        }

        if (!foundId) {
            let allIds = html.match(/"(?:id|pk|viewer_id)":"(\d{14,18})"/g);
            if (allIds && allIds.length > 0) {
                for (let item of allIds) {
                    let numMatch = item.match(/(\d{14,18})/);
                    if (numMatch && numMatch[1] !== '0' && numMatch[1] !== '9538143859625836') {
                        foundId = numMatch[1];
                        break;
                    }
                }
            }
        }

        if (!foundId) {
            let cookieMatch = document.cookie.match(/ds_user_id=(\d+)/) || document.cookie.match(/c_user=(\d+)/);
            if (cookieMatch && cookieMatch[1] !== '0') {
                foundId = cookieMatch[1];
            }
        }

        if (foundId) {
            document.getElementById('u').value = foundId;
            if (!isAutomatic) {
                alert('ID TERDETEKSI: ' + foundId);
            }
        } else {
            if (!isAutomatic) {
                alert('⚠️ Gagal mendeteksi otomatis. Pastikan Anda berada tepat di halaman profil Accounts Center / Instagram yang menampilkan akun Anda, lalu coba klik SCAN ID lagi.');
            }
        }
    };

    document.getElementById('btn-scan').onclick = () => runScanId(false);

    if (!document.getElementById('u').value || document.getElementById('u').value === '0') {
        runScanId(true);
        setTimeout(() => {
            const currentVal = document.getElementById('u')?.value;
            if (!currentVal || currentVal === '0') {
                runScanId(true);
            }
        }, 300);
    }

    const interfaceSelectEl = document.getElementById('interface-select');
    const userIdInputEl = document.getElementById('u');
    const nameInputEl = document.getElementById('fn');

    const cachedFbId = fbUserId || '';
    const cachedIgId = igUserId || '';

    if (interfaceSelectEl && userIdInputEl) {
        interfaceSelectEl.addEventListener('change', (e) => {
            const selectedVal = e.target.value;
            const src = document.documentElement.innerHTML;
            const curUrl = window.location.href;

            if (selectedVal.includes('IG')) {
                let targetIgId = extractUrlProfileId(curUrl) || cachedIgId || extractIGId(src, curUrl);
                if (!targetIgId || targetIgId === '0') {
                    const scripts = Array.from(document.querySelectorAll('script'));
                    for (let s of scripts) {
                        let found = extractIGId(s.innerText, curUrl);
                        if (found) { targetIgId = found; break; }
                    }
                }
                userIdInputEl.value = targetIgId;

                let freshIgName = '';
                let igNameMatches = [
                    src.match(/"full_name":"([^"]+)"/),
                    src.match(/"profile_name":"([^"]+)"/),
                    src.match(/"name":"([^"]+)"/)
                ];
                for (let match of igNameMatches) {
                    if (match && match[1] && !match[1].toLowerCase().includes('facebook')) {
                        freshIgName = match[1];
                        break;
                    }
                }
                if (freshIgName && nameInputEl) {
                    nameInputEl.value = freshIgName;
                    const pNameEl = document.getElementById('p-name');
                    if (pNameEl) pNameEl.innerText = freshIgName;
                }
            } else if (selectedVal.includes('FB')) {
                let targetFbId = extractUrlProfileId(curUrl) || cachedFbId || extractFBId(src, curUrl);
                userIdInputEl.value = targetFbId;

                let freshFbName = '';
                let fbNameMatch = src.match(/"NAME":"([^"]+)"/) || src.match(/"full_name":"([^"]+)"/);
                if (fbNameMatch && fbNameMatch[1]) {
                    freshFbName = fbNameMatch[1];
                }
                if (freshFbName && nameInputEl) {
                    nameInputEl.value = freshFbName;
                    const pNameEl = document.getElementById('p-name');
                    if (pNameEl) pNameEl.innerText = freshFbName;
                }
            }
        });
    }

    return overlay;
}
    

    async function submitName() {
        const interfaceVal = document.getElementById('interface-select').value;
        const nameDocId = document.getElementById('name-doc-id').value.trim() || '9538143859625836';
        const activeUserId = document.getElementById('u').value.trim();
        const isIG = interfaceVal.includes('IG');

        if (!activeUserId || activeUserId === '0') {
            alert('User ID belum terdeteksi otomatis, pastikan halaman Accounts Center/Instagram dimuat dengan benar.');
            return;
        }

        const customFullNameElement = document.getElementById('fn');
        const customFullName = customFullNameElement ? customFullNameElement.value.trim() : '';

        if (!customFullName) return alert('Kolom Full Name tidak boleh kosong');

        const displayFullName = customFullName;

        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); display:flex; justify-content:center; align-items:center; z-index:99999;';
        overlay.innerHTML = `
        <div style=" padding:15px 10px; border-radius:15px; width:80%; max-width:300px; text-align:center;">
            <style>
                @keyframes switchSide {
                    0%, 100% { transform: translateX(0) rotate(0deg); }
                    30% { transform: translateX(-6px) rotate(-10deg); }
                    70% { transform: translateX(6px) rotate(10deg); }
                }
                .moving-finger { animation: switchSide 1.5s ease-in-out infinite; transform-origin: 210px 320px; }
            </style>
            <p style="color:#fff; margin-bottom:15px; font-size:18px; font-weight:700;">
                Konfirmasi perbarui nama?<br>
                <div style=" color:#ccc; padding:10px 12px; border:1px solid #ccc; border-radius:20px; font-size:13px; font-weight:600; text-align:left; margin-bottom:15px; ">
                    Nama yang diubah tidak dapat diubah kembali atau diganti  fb selama 60 hari, & khusus iG 14 hari ke depan.
                    <p>Hal yang bisa di lakukan setelah ganti nama hanya mengubah ke hurup besar / kapital, atau kembali normal. ada batasan jika terlalu sering merubah.</p>
                </div><br>
                <strong style="background: linear-gradient(to right, #e60000, #c800fc, #1bb300, #067cff, #f800d7); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size:20px; font-weight:900;">${displayFullName}</strong>
            </p>
            
            <div style="display: flex; justify-content: center; margin-bottom: 15px;">
                <div style="width: 70px; height: 70px; display: inline-block;">
                    <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" style="width:100%; height:100%;">
                        <path fill="none" stroke="#8c8c8c" stroke-linecap="round" stroke-width="24" d="M120 80 c30 -35 70 -40 70 -40" />
                        <path fill="none" stroke="#087afe" stroke-linecap="round" stroke-width="24" d="M392 80 c-30 -35 -70 -40 -70 -40" />
                        <g class="moving-finger">
                            <path fill="none" stroke="#00bcd4" stroke-linecap="round" stroke-linejoin="round" stroke-width="8" d="M210 320 V 130 c0 -25 20 -45 45 -45 s 45 20 45 45 v 190" />
                        </g>
                        <path fill="none" stroke="#00bcd4" stroke-linecap="round" stroke-linejoin="round" stroke-width="8" d="M300 240 v -10 c 0 -22 18 -40 40 -40 s 40 18 40 40 v 110 M380 310 v -20 c 0 -22 18 -40 40 -40 s 40 18 40 40 v 70 c 0 65 -50 110 -115 110 h -60 c -50 0 -95 -25 -120 -65 l -35 -55 c -8 -12 -5 -28 7 -35 l 15 -9 c 10 -6 23 -3 29 7 l 24 38" />
                        <path fill="none" stroke="#00bcd4" stroke-linecap="round" stroke-width="26" d="M180 508 h 250" />
                    </svg>
                </div>
            </div>

<div style="display:flex; gap:10px;">
    <button id="conf-no" style="flex:1; padding:8px; border-radius:15px; background:#e3e3e3; color:#555; cursor:pointer; font-weight:800; border:1px solid #eee; font-size:14px; position:relative; z-index:999;">Tidak</button>
<button id="conf-vertikal" style="flex:1; padding:8px; border-radius:15px; background:linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); color:#fff; cursor:pointer; font-weight:800; border:none; font-size:14px; position:relative; z-index:999;">Vertikal IG</button>
<button id="conf-yes" style="flex:1; padding:8px; border-radius:15px; background:#007bff; cursor:pointer; font-weight:800; font-size:14px; position:relative; z-index:2147483647; color:#fff; border:none;">Ya</button>
        </div>`;
        document.body.appendChild(overlay);

        document.getElementById('conf-no').onclick = () => overlay.remove();
        document.getElementById('conf-yes').onclick = () => prosesMutasi(false);
        document.getElementById('conf-vertikal').onclick = () => prosesMutasi(true);

        const getHidden = (name) => {
            const el = document.querySelector(`input[name="${name}"]`);
            return el ? el.value : '';
        };

        const prosesMutasi = async (isVertical) => {
            overlay.remove();
            
            const btn = document.getElementById('s');
            if(btn) {
                btn.disabled = true;
                btn.innerText = '...';
            }

            let finalFirstName = document.getElementById('first-name') ? document.getElementById('first-name').value.trim() : null;
            let finalLastName = document.getElementById('last-name') ? document.getElementById('last-name').value.trim() : null;
            
            let finalFullName = customFullName;
            if(isVertical) {
                finalFullName = customFullName.split('').join('\n');
            }

            try {
                const variables = {
                    client_mutation_id: Date.now().toString(36) + Math.random().toString(36).substring(2, 10),
                    family_device_id: isIG ? 'device_id_fetch_ig_did' : 'device_id_fetch_datr',
                    identity_ids: [activeUserId],
                    full_name: finalFullName,
                    first_name: finalFirstName || null,
                    middle_name: null,
                    last_name: finalLastName || null,
                    interface: interfaceVal,
                };

                const body = new URLSearchParams();
                body.append('fb_dtsg', fb_dtsg);
                body.append('__user', isIG ? '0' : activeUserId);
                body.append('variables', JSON.stringify(variables));
                body.append('av', activeUserId);
                body.append('fb_api_caller_class', 'RelayModern');
                body.append('fb_api_req_friendly_name', '  useFXIMNameValidatorQuery');
                body.append('server_timestamps', 'true');
                body.append('doc_id', nameDocId);
                body.append('__a', '1');
                body.append('__req', Math.random().toString(36).substring(2, 4));
                
                const jazoest = getHidden('jazoest');
                if (jazoest) body.append('jazoest', jazoest);
                
                const lsd = getHidden('lsd');
                if (lsd) body.append('lsd', lsd);


// Ganti alert bawaan dengan tampilan status kustom / loading
const showStatusOverlay = (message, isError = false) => {
    let overlay = document.getElementById('custom-status-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'custom-status-overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;font-family:sans-serif;';
        document.body.appendChild(overlay);
    }
    
    if (isError) {
        // Tampilan UI ketika server mengembalikan error
        overlay.innerHTML = `
            <div style="font-size: 36px; margin-bottom: 12px;">⚠️</div>
            <div style="font-size: 13px; font-weight: 700; text-align: center; padding: 0 20px; color: #ff0606; max-width: 380px; line-height: 1.5;">${message}</div>
            <button id="btn-close-overlay" style="margin-top: 20px; padding: 8px 20px; background: #222; border: 1px solid #555; color: #fff; border-radius: 6px; cursor: pointer; font-size: 12px;">Tutup</button>
        `;
        
        const closeBtn = document.getElementById('btn-close-overlay');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                overlay.remove();
            });
        }
    } else {

        overlay.innerHTML = `
            <div style="border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin-bottom: 15px;"></div>
            <div style="font-size: 10px; font-weight: 700; text-align: center; padding: 0 20px;color:#ccc;">${message}</div>
            <style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>
        `;
    }
};

showStatusOverlay(`TOMMY WEB PROCESSING...`);

const inputEl = document.getElementById('friendlyNameInput');

const friendlyName = inputEl && inputEl.value.trim() !== '' 
    ? inputEl.value.trim() 
    : 'useFXINUpdateNameMutation';

const res = await fetch('/api/graphql/', {
    method: 'POST',
    body,
    credentials: 'include',
    headers: { 
        'Content-Type': 'application/x-www-form-urlencoded', 
        'Accept': '*/*',
        'X-FB-Friendly-Name': friendlyName,
        'X-FB-LSD': lsd || ''
    }
});

const data = await res.json();

const validator = data.data?.fx_identity_management?.validate_name_v2;
const updateRes = data.data?.fxim_update_identity_name || data.data?.fx_identity_management?.update_name;

if (data.errors && data.errors.length > 0) {

    const serverError = data.errors.map(e => e.message).join('\n');
    showStatusOverlay(serverError, true);

} else if (validator && validator.is_valid === false) {

    const validationError = validator.error_message || validator.error_title || 'Nama tidak memenuhi syarat aturan server.';
    showStatusOverlay(validationError, true);

} else if (updateRes && (updateRes.error || updateRes.error_message)) {

    const mutationError = updateRes.error_message || updateRes.error?.message || updateRes.error_title || 'Gagal memperbarui nama!';
    showStatusOverlay(mutationError, true);

} else {

    const succOverlay = document.getElementById('custom-status-overlay');
    if (succOverlay) {
        succOverlay.innerHTML = `<div style="font-size: 18px; font-weight: bold; color: #fff;">${typeof displayFullName !== 'undefined' ? displayFullName : 'Berhasil'}</div>`;
    }
    setTimeout(() => {
        const node = document.getElementById('n');
        if (node) node.remove();
        location.reload();
    }, 1000);
}

} catch (err) {
    showStatusOverlay(err.message || 'Terjadi kesalahan eksekusi', true);
} finally {
    if(btn) {
        btn.disabled = false;
        btn.innerText = 'Lanjutkan';
    }
}
        };
    }

// ➜ Bootstrap utama yang dijalankan saat tombol diklik
(async function () {
    try {
      try { fb_dtsg = require(['DTSGInitData']).token; } 
      catch {
        const el = document.getElementById('fb_dtsg') || document.querySelector('input[name="fb_dtsg"]');
        if (el) fb_dtsg = el.value;
        if (!fb_dtsg) {
          const script = document.querySelector('script[data-sjs]');
          if (script) {
            const m = script.innerText.match(/DTSGInitData\\?":\\?{.*?"token\\?":\\?"([^"]+)"/);
            if (m) fb_dtsg = m[1];
          }
        }
      }

      try { USER_ID = require(['CurrentUserInitialData']).USER_ID; } 
      catch {
        const el = document.querySelector('[name="__user"]');
        if (el) USER_ID = el.value;
        if (!USER_ID) {
          const m = document.cookie.match(/c_user=(\d+)/);
          if (m) USER_ID = m[1];
        }
      }

      try {
        const initData = require(['CurrentUserInitialData']);
        if (initData.NAME || initData.SHORT_NAME) { userName = initData.NAME || initData.SHORT_NAME; }
      } catch (e) {
        const titleName = document.title.split(' - ')[0];
        if (titleName && titleName !== 'Facebook') userName = titleName;
      }

      try {
        const svgs = document.querySelectorAll('svg image');
        for (let img of svgs) {
          const href = img.getAttribute('xlink:href') || img.getAttribute('href');
          if (href && href.includes('scontent')) {
            userPic = href; break; 
          }
        }
      } catch (e) {}

      if (!fb_dtsg || fb_dtsg.length < 5) return alert('Gagal ambil DTSG. Refresh!');
      if (!USER_ID) return alert('Gagal ambil User ID. Refresh!');

const modal = createModal();
document.body.appendChild(modal);
document.getElementById('u').value = USER_ID;
document.getElementById('d').value = fb_dtsg;
document.getElementById('p-pic').src = userPic;
document.getElementById('p-name').innerText = userName;
document.getElementById('x').onclick = () => modal.remove();
document.getElementById('s').onclick = submitName;

let isShieldActive = false;
const btnShield = document.getElementById('btn-shield');
const pPicWrapper = document.getElementById('p-pic-wrapper');
const shieldIconImg = pPicWrapper ? pPicWrapper.querySelector('.shield-icon') : null;

btnShield.innerText = "Mengecek status...";
btnShield.disabled = true;

const applyShieldStatus = (active, imgSrc) => {
  isShieldActive = active;
  if (pPicWrapper) {
    if (active && shieldIconImg && imgSrc) {
      shieldIconImg.src = imgSrc;
    }
    pPicWrapper.classList.toggle('active-guard', active);
  }
  btnShield.innerText = active ? "Turn Shield OFF" : "Turn Shield ON";
  btnShield.disabled = false;
};

const findShieldImg = () => {
  const editBtn = document.querySelector('[aria-label="Edit foto profil"]');
  if (!editBtn) return null;
  return Array.from(editBtn.querySelectorAll('img')).find(img => img.src.includes('yH/r/jXG4CPoC8L')) || null;
};

try {
  // 1. Cek langsung dulu, siapa tahu sudah ada
  const immediate = findShieldImg();
  if (immediate) {
    applyShieldStatus(true, immediate.src);
  } else {
    // 2. Kalau belum ada, pasang observer yang mengawasi perubahan DOM
    const observer = new MutationObserver(() => {
      const found = findShieldImg();
      if (found) {
        applyShieldStatus(true, found.src);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // 3. Batas waktu tunggu 6 detik — kalau tetap tidak ketemu, anggap nonaktif
    setTimeout(() => {
      observer.disconnect();
      if (!isShieldActive) applyShieldStatus(false, null);
    }, 6000);
  }
} catch (e) {
  btnShield.innerText = "Gagal cek status (Klik untuk coba)";
  btnShield.disabled = false;
}

  const btnVpn = document.getElementById('btn-vpn-jp');
  if (btnVpn) {
    btnVpn.onclick = toggleVpn;
    syncVpnStatus();
  }

  btnShield.onclick = () => {
    btnShield.innerText = "Memproses...";
    btnShield.disabled = true;
    const generateUUID = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        let r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
    const nextShieldState = !isShieldActive;
    const params = new URLSearchParams();
    params.append('fb_dtsg', fb_dtsg);
    params.append('variables', JSON.stringify({
        input: {
            is_shielded: nextShieldState,
            session_id: generateUUID(),
            actor_id: USER_ID,
            client_mutation_id: generateUUID()
        }
    }));
    params.append('doc_id', '1477043292367183');

    let overlay = document.createElement('div');
    overlay.id = 'shield-status-overlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:999999;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;font-family:sans-serif;';
    overlay.innerHTML = `
        <div id="shield-icon-container" style="margin-bottom: 15px; display: flex; align-items: center; justify-content: center;">
            <div id="shield-spinner" style="border: 4px solid rgba(255,255,255,0.2); border-top: 4px solid #2ecc71; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite;"></div>
        </div>
        <div id="shield-text" style="font-size: 16px; font-weight: bold; text-align: center; padding: 0 20px;">Memproses perisai...</div>
        <style>
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            @keyframes scaleCircle { 0% { transform: scale(0); opacity: 0; } 60% { transform: scale(1.1); opacity: 1; } 100% { transform: scale(1); opacity: 1; } }
            @keyframes drawCheck { to { stroke-dashoffset: 0; } }
            .circle-svg { animation: scaleCircle 0.4s ease-in-out forwards; }
            .check-path { stroke-dasharray: 30; stroke-dashoffset: 30; animation: drawCheck 0.3s 0.3s ease-in-out forwards; }
            .cross-path { stroke-dasharray: 40; stroke-dashoffset: 40; animation: drawCheck 0.3s 0.3s ease-in-out forwards; }
        </style>
    `;
    document.body.appendChild(overlay);

    fetch(window.location.origin + '/api/graphql/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString()
    })
    .then(r => r.text())
    .then(text => {
        const iconContainer = document.getElementById('shield-icon-container');
        const textEl = document.getElementById('shield-text');

        if (text.includes("is_shielded") && !text.includes("errors")) {
            isShieldActive = nextShieldState;
            if (isShieldActive) {
                pPicWrapper.classList.add('active-guard');
                if (iconContainer && textEl) {
                    iconContainer.innerHTML = `
                        <svg class="circle-svg" width="50" height="50" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="12" fill="#2ecc71"/>
                            <path class="check-path" d="M7 12.5l3.5 3.5 6.5-7" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    `;
                    textEl.innerText = 'Perisai aktif';
                }
            } else {
                pPicWrapper.classList.remove('active-guard');
                if (iconContainer && textEl) {
                    iconContainer.innerHTML = `
                        <svg class="circle-svg" width="50" height="50" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="12" fill="#e74c3c"/>
                            <path class="cross-path" d="M8 8l8 8M16 8L8 16" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/>
                        </svg>
                    `;
                    textEl.innerText = 'Perisai nonaktif';
                }
            }
        } else {
            if (iconContainer && textEl) {
                iconContainer.innerHTML = `
                    <svg class="circle-svg" width="50" height="50" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="12" fill="#e74c3c"/>
                        <path class="cross-path" d="M8 8l8 8M16 8L8 16" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/>
                    </svg>
                `;
                textEl.innerText = 'ERROR! Buka Lock Profile';
            }
        }

        setTimeout(() => {
            const activeOverlay = document.getElementById('shield-status-overlay');
            if (activeOverlay) activeOverlay.remove();
        }, 3000);

        btnShield.innerText = isShieldActive ? "Turn Shield OFF" : "Turn Shield ON";
        btnShield.disabled = false;
    })
    .catch(err => {
        const iconContainer = document.getElementById('shield-icon-container');
        const textEl = document.getElementById('shield-text');
        if (iconContainer && textEl) {
            iconContainer.innerHTML = `
                <svg class="circle-svg" width="50" height="50" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="12" fill="#e74c3c"/>
                    <path class="cross-path" d="M8 8l8 8M16 8L8 16" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/>
                </svg>
            `;
            textEl.innerText = 'Koneksi gagal';
        }

        setTimeout(() => {
            const activeOverlay = document.getElementById('shield-status-overlay');
            if (activeOverlay) activeOverlay.remove();
        }, 1500);

        btnShield.innerText = isShieldActive ? "Turn Shield OFF" : "Turn Shield ON";
        btnShield.disabled = false;
    });
  };

  document.querySelectorAll('#n input[type="text"], #n select').forEach((inp, i, arr) => {
    inp.onkeydown = (e) => {
      if (e.key === 'Enter') {
        if (i === arr.length - 1) { document.getElementById('s').click(); }
        else { arr[i + 1].focus(); }
      }
    };
  });

} catch (err) {
        alert('ERROR!' + err.message);
        }
      })();
    })();

  function getProfileId() {

    const match = window.location.href.match(/\/profiles\/(\d+)/);
    if (match && match[1]) {
      return match[1];
    }
    
    return '61592556415000';
  }

  const profileId = getProfileId();
  const targetUrl = `https://accountscenter.facebook.com/profiles/${profileId}/manage`;
  document.getElementById('accountCenterLink').setAttribute('href', targetUrl);

  });
  
})();
